﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonacciChallenge
{
    public class Challenge
    {
        /*
         * Write a method that returns any given number in the Fibonnacci sequence.
         * 0,1,1,2,3,5,8,13,21...
         */
		 
        public long Fib(int n){ 
            return 0;
        }
    }
}
